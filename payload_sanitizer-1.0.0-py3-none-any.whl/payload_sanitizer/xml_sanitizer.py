# xml_sanitizer.py
import re
from .common import basic_clean

# XML 1.0 illegal characters
XML_INVALID_CHARS = re.compile(
    r"[^\u0009\u000A\u000D\u0020-\uD7FF\uE000-\uFFFD]"
)

def sanitize_xml(text: str) -> str:
    text = basic_clean(text)
    return XML_INVALID_CHARS.sub("", text)
