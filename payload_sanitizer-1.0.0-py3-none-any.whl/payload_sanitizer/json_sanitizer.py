# json_sanitizer.py
import json
import re

ESCAPED_JSON_CONTROLS = re.compile(
    r"\\u00(0[0-9A-Fa-f]|1[0-9A-Fa-f])"
)

NBSP = "\u00A0"

def sanitize_json(text: str, strict: bool = False) -> str:
    text = text.encode("utf-8", errors="ignore").decode("utf-8")

    obj = json.loads(text)

    clean = json.dumps(obj, ensure_ascii=False)

    if strict:
        clean = ESCAPED_JSON_CONTROLS.sub("", clean)

        # Normalize non-breaking spaces
        clean = clean.replace(NBSP, " ")

    return clean

