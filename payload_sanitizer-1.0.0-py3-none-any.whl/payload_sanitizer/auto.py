# auto.py
from .xml_sanitizer import sanitize_xml
from .json_sanitizer import sanitize_json
from .ndjson_sanitizer import sanitize_ndjson
from .csv_sanitizer import sanitize_csv
from .common import basic_clean

def sanitize_payload(text: str, payload_type: str = "auto", strict: bool = False) -> str:
    stripped = text.lstrip()

    if payload_type == "auto":
        if stripped.startswith("<"):
            payload_type = "xml"
        elif stripped.startswith("{") or stripped.startswith("["):
            payload_type = "json"
        else:
            payload_type = "text"

    if payload_type == "xml":
        return sanitize_xml(text)

    if payload_type == "json":
        return sanitize_json(text, strict=strict)

    if payload_type == "ndjson":
        return sanitize_ndjson(text, strict=strict)

    if payload_type == "csv":
        return sanitize_csv(text)

    return basic_clean(text)
