# csv_sanitizer.py
from .common import basic_clean

def sanitize_csv(text: str) -> str:
    return basic_clean(text)
