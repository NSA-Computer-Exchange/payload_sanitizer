# ndjson_sanitizer.py
import json
from .common import enforce_utf8
from .json_sanitizer import sanitize_json

def sanitize_ndjson(text: str, strict: bool = False) -> str:
    lines = []
    text = enforce_utf8(text)

    for lineno, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        try:
            clean = sanitize_json(line, strict=strict)
            lines.append(clean)
        except Exception as e:
            raise ValueError(f"Invalid JSON on line {lineno}: {e}")

    return "\n".join(lines) + "\n"
