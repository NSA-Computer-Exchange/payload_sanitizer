# common.py
import re

# Invisible but problematic Unicode
INVISIBLE_UNICODE = re.compile(r"[\u200B\u200C\u200D\u2060\uFEFF]")

# Control chars except TAB, LF, CR
CONTROL_CHARS = re.compile(r"[\x00-\x08\x0B\x0C\x0E-\x1F]")

def enforce_utf8(text: str) -> str:
    return text.encode("utf-8", errors="ignore").decode("utf-8")

def basic_clean(text: str) -> str:
    text = enforce_utf8(text)
    text = INVISIBLE_UNICODE.sub("", text)
    text = CONTROL_CHARS.sub("", text)
    return text
